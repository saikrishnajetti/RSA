var  inputString = document.getElementById("input")  
        .value;  
    var outputString = document.getElementsByClassName("enc"); 
    
    
    
	function encryption()  
{  
         inputString = document.getElementById("input")  
        .value;  
    outputString = document.getElementsByClassName("enc"); 
    var asciiArr = new Array();  
    var atozArr = new Array();  
    var encryptedString = new Array();  
    if(inputString.length != 0)  
    {  
        outputString.innerHTML = "";  
        //First Step: Convert all characters in ascii code     
        for(i = 0; i < inputString.length; i++)  
        {  
            asciiArr[i] = inputString[i].charCodeAt(0);  
        }  
        //Second Step: Fill AtoZ array in capital or small letters     
        for(i = 0, code = 65; i < 26; i++, code++)  
        {  
            atozArr[i] = String.fromCharCode(code);  
        }  
        //Third Step: Choose random single character index from A to Z    
        position = randomIndexFromInterval(0, atozArr.length - 1);  
        positionAscii = atozArr[position].charCodeAt(0);  
        //Fourth Step: Addition of every inputString element to positionAscii    
        for(i = 0; i < inputString.length; i++)  
        {  
            encryptedString[i] = parseInt(asciiArr[i]) + parseInt(atozArr[position].charCodeAt(0));  
        }  
        //Fifth Step: Attach key to encrypted string    
        encryptedString[asciiArr.length] = positionAscii;  
        //Sixth Step: Finally your encryption is ready to send    
        for(i = 0; i < encryptedString.length; i++)  
        {  
            outputString.innerHTML = outputString.innerHTML + String.fromCharCode(encryptedString[i]);  
        }  
        document.getElementById("input")  
            .value = outputString.innerHTML;  
    }  
    else  
    {  
	    document.getElementsByClassName("enc") 
            .innerHTML = "Error: Value can not be empty.";  
        return false;  
    }  
}  

function randomIndexFromInterval(min, max)  
{  
    return Math.floor(Math.random() * (max - min + 1) + min);  
}  
